import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class good_cos extends JFrame {

    public static ArrayList<String>good_cosmetics=new ArrayList<>();

    public good_cos() {

        setTitle("잘맞았던 화장품");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 500);
        setLocationRelativeTo(null);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridLayout(0, 1, 5, 5));

        contentPanel.add(new JLabel("잘맞았던 화장품"));

        contentPanel.add(new JLabel("판매사 명"));
        JTextField sellerField = new JTextField();
        contentPanel.add(sellerField);

        contentPanel.add(new JLabel("제품 명"));
        JTextField productField = new JTextField();
        contentPanel.add(productField);

        JButton addbtn2 = new JButton("추가");
        contentPanel.add(addbtn2);
        addbtn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new good_cos();
            }
        });

        JButton submitbtn2 = new JButton("제출");
        contentPanel.add(submitbtn2);
        submitbtn2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String Seller=sellerField.getText();
                String Product=productField.getText();
                good_cosmetics.add(Seller+"_"+Product);
                dispose();
                sellerField.setText("");
                productField.setText("");
                } });

        JScrollPane Scrolll = new JScrollPane(contentPanel);
        add(Scrolll);

        setVisible(true);
    }


}
