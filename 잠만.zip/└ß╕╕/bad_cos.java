import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class bad_cos extends JFrame {

    public static ArrayList<String> bad_cosmetics= new ArrayList<>();

    public bad_cos() {
        setTitle("안맞았던 화장품");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 500);
        setLocationRelativeTo(null);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridLayout(0, 1, 5, 5));

        contentPanel.add(new JLabel("안맞았던 화장품"));

        contentPanel.add(new JLabel("판매사 명"));
        JTextField sellerField = new JTextField();
        contentPanel.add(sellerField);

        contentPanel.add(new JLabel("제품 명"));
        JTextField productField = new JTextField();
        contentPanel.add(productField);

        JButton addbtn1 = new JButton("추가");
        contentPanel.add(addbtn1);
        addbtn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new bad_cos();
            }
        });

        JButton submitbtn1 = new JButton("제출");
        contentPanel.add(submitbtn1);
        submitbtn1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String seller = sellerField.getText();
                String product = productField.getText();

                bad_cosmetics.add(seller+"_"+product);
                JOptionPane.showMessageDialog(null, "저장되었습니다");
                sellerField.setText("");
                productField.setText("");

                dispose();
            }

        });

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        add(scrollPane);

        setVisible(true);
    }


}
