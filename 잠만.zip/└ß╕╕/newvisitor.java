import javax.swing.*;
import java.awt.*;

public class newvisitor extends JFrame {

    public newvisitor(CheckMem.ContactNode<String, String> user, CheckMem.ContactNode<String, String> idpw) {
        setTitle("새로운 가입 요청");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 200);

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("새로운 가입 요청이 있습니다!"));
        panel.add(new JLabel("이름: " + user.Key));
        panel.add(new JLabel("전화번호: " + user.Value));

        JButton approve = new JButton("가입 승인");
        approve.addActionListener(e -> {
            CheckMem.registeredAccounts.add(new CheckMem.ContactNode<>(idpw.Key, idpw.Value));
            JOptionPane.showMessageDialog(this, "가입이 승인되었습니다.");
            dispose();
        });

        panel.add(approve);
        add(panel);
        setVisible(true);
    }
}
