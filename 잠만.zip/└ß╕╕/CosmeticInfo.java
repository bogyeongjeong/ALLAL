import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.nio.Buffer;

public class CosmeticInfo extends JFrame {

    CosmeticInfo(){
        setTitle("화장품 정보 제출");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300,500);
        setLocationRelativeTo(null);
        setVisible(true);
        JPanel cosmeticpanel = new JPanel();
        cosmeticpanel.setLayout(new GridLayout(0,1));

        JLabel seller=new JLabel("판매사 명");
        JTextField sellerfield=new JTextField(14);
        add(seller);
        add(sellerfield);
        JLabel product=new JLabel("제품명");
        JTextField productfield=new JTextField(14);
        add(product);
        add(productfield);

        JLabel allergycheck=new JLabel("알레르기 성질 유무");
        JButton checking=new JButton("알레르기가 있다면 눌러주세요!");
        add(allergycheck);
        add(checking);
        checking.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CheckAllForCos();

            }
        });
        JLabel special=new JLabel("특이사항 입력");
        add(special);
        JButton speciall=new JButton("특이사항이 있다면 눌러주세요!");
        add(speciall);
        speciall.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Special();
            }
        });

        JLabel inform=new JLabel("제품 정보 입력");
        add(inform);
        JTextArea inform2=new JTextArea();

        JButton submit=new JButton("제출");
        add(submit);
        submit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try{
                    String Product_name=productfield.getText().trim();
                    String Seller_name=sellerfield.getText().trim();
                    BufferedWriter bw=new BufferedWriter(new FileWriter(Product_name+"_"+Seller_name+".txt"));
                    bw.write("판매사_제품명:"+sellerfield.getText()+"_");
                    bw.write(productfield.getText()+"\n");
                    for(String alll:CheckAllForCos.Allergy_Check_C){
                        bw.write(alll+" ");

                    }
                    bw.write("\n");
                    bw.write("제품 정보:"+inform2.getText()+"\n");

                    bw.close();

                    JOptionPane.showMessageDialog(null, "정보가 저장되었습니다!");
                    dispose();

                }
                catch(Exception ex){
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "저장 중 오류 발생");

                }


            }
        });



    }
}
