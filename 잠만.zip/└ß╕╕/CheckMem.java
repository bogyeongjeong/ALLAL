import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class CheckMem extends JFrame {

    public static List<ContactNode<String, String>> pendingMembers = new ArrayList<>();
    public static List<ContactNode<String, String>> registeredAccounts = new ArrayList<>();

    public static class ContactNode<K, V> {
        public K Key;
        public V Value;

        public ContactNode(K key, V value) {
            this.Key = key;
            this.Value = value;
        }
    }

    public CheckMem() {
        setTitle("멤버 관리");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        JPanel panel = new JPanel(new GridLayout(0, 1));

        JButton checkNew = new JButton("새 요청 보기");
        checkNew.addActionListener(e -> {
            for (int i = 0; i < pendingMembers.size(); i++) {
                ContactNode<String, String> user = pendingMembers.get(i);
                ContactNode<String, String> idpw = user_info.idPwList.get(i);
                new newvisitor(user, idpw);
            }
        });

        panel.add(checkNew);
        add(panel);
        setVisible(true);
    }
}
