import javax.swing.*;
import java.awt.*;

public class Login extends JFrame {
    Login(){
        setTitle("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,500);
        setLocationRelativeTo(null);
        setVisible(true);

        JPanel Loginpanel = new JPanel();
        Loginpanel.setLayout(new GridLayout(0,1));
        Loginpanel.add(new JLabel("ID"));
        Loginpanel.add(new JLabel("Password"));
        JTextField id = new JTextField(10);
        JPasswordField password = new JPasswordField(10);
        Loginpanel.add(id);
        Loginpanel.add(password);

        JButton LoginButton = new JButton("Login");
        LoginButton.addActionListener(e -> {
            new Search_Cos();
        });


    }

}
